CREATE TABLE Category (
  category_id INT AUTO_INCREMENT,
  category_name VARCHAR(50) NOT NULL,
  category_type VARCHAR(255) NOT NULL,
  PRIMARY KEY (category_id)
);